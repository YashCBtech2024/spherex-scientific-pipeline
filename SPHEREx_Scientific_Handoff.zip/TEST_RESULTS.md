# Test Results

Executed `.venv312\Scripts\python.exe -m pytest tests -q` on 2026-11-07. Result: **7 passed**. Pytest emitted a pytest-asyncio deprecation warning about unspecified fixture loop scope; no test failures.
