# SPHEREx Scientific Handoff

This archive packages the science-side contribution for teammate integration. It excludes virtual environments, caches, reference repositories and duplicate raw files. Raw inputs are included as copies; source workspace originals remain untouched.

## Contents

- `data/raw/`: three original FITS observations used for this analysis.
- `data/processed/`: May 2025 cutout products, three epoch cutouts, and validated common-grid aligned FITS, mask, metadata and PNG comparisons.
- `data/catalogues/`: immutable historical catalogues plus reproduced per-epoch detections, photometry, provisional associations, candidate reassessment and plots.
- `data/integration/`: CSV import table, provisional null-preserving JSON examples and manifest. Candidate JSON is intentionally marked incompatible with the current strict backend model until teammates add nullable fields/provenance support.
- `science/`: reusable FITS, WCS, alignment, mask, source analysis and integration export code.
- `tests/`: automated tests.
- `docs/`: project context, audit, recovered workflow, scientific/integration handoffs and environment record.

## Reproduce

Use Python 3.12 and install `requirements.txt`. From the project root, the validated products and analysis can be rerun with the project functions documented in `docs/RECOVERED_COLAB_WORKFLOW.md` and source modules under `science/`. Run tests: `.venv312\Scripts\python.exe -m pytest tests -q` (or `python -m pytest tests -q` in an equivalent environment). Expected current result: 7 passed.

The aligned common mask contains 2,259 of 3,720 pixels; outside-mask values are NaN. Bilinear reprojection correlates pixels. Photometry is preliminary and uncorrected; uncertainties omit interpolation covariance. No Gaia/JPL validation or moving-object classification is claimed. See `docs/SCIENTIFIC_HANDOFF.md` and `docs/TEAMMATE_INTEGRATION_HANDOFF.md`.
