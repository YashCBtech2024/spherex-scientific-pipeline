# SPHEREx Sky Explorer

## Project vision

This NASA SPHEREx challenge project is building a public-facing web application that makes SPHEREx observations easier to explore and understand. SPHEREx maps the whole sky in 102 bands of near-infrared light, with repeated observations that can reveal changes in position and brightness. The application will help users inspect those observations and investigate sources, while presenting scientific uncertainty clearly.

The long-term application is intended to let users:

- Explore sky images and select a region by right ascension (RA) and declination (Dec).
- Find observations of that region across dates and compare or blink epochs.
- Compare brightness and inspect variable sources, source positions, observation histories, and catalogue matches.
- Investigate possible moving objects and see classifications with appropriate confidence and uncertainty.
- Eventually explore the full available SPHEREx observation collection, beyond the initial test region.

The scientific analysis is a foundation for this application, not the final product. Candidate associations are preliminary and must not be presented as confirmed moving objects. Scientific accuracy, preservation of original data, reproducibility, and clear communication for non-astronomers guide development.

## Current test case

The initial investigation uses three D1 observation epochs: April 25, 2025; May 9, 2025; and approximately May 26, 2026. The stated test-region center is **RA 151.81441452°, Dec +2.82631029°**. The workspace contains four FITS files (including two May 2026 variants), a preliminary 51-detection catalogue, and two close May 2025–May 2026 associations.

Existing reports describe WCS, photometry, cross-epoch matching, and candidate analysis. These are preliminary scientific work, not a production pipeline or independently complete validation. In particular, Gaia result provenance and Solar System object cross-matching need further verification. Read [the project vision and roadmap](docs/PROJECT_VISION.md) for intended scope and development phases, and [the scientific audit](docs/SCIENTIFIC_AUDIT_REPORT.md) for the current audit record and its limitations.

## Intended architecture

- **Science pipeline:** Python astronomy tools (Astropy, Photutils, and related libraries) for FITS/WCS handling, source detection, photometry, astrometric calibration, epoch matching, and validation.
- **Backend:** FastAPI or a suitable alternative to provide observation metadata, catalogues, queries, and image cutouts.
- **Frontend:** A modern responsive sky viewer with coordinate search, epoch controls, image blinking, source overlays, and lightcurves.
- **Data storage:** Organized raw, processed, catalogue, and external-reference data, retaining original astronomical inputs.

These are planned components. At present the repository mainly contains data, documentation, and standalone analysis utilities; the interactive application and modular scientific pipeline have not yet been implemented.

## Repository guide

| Path | Contents |
|---|---|
| `data/raw/` | Local SPHEREx FITS observations |
| `data/catalogues/` | Historical detection, photometry, and association tables |
| `data/external/` | External-query artifacts and observation metadata; query success varies and must be checked per artifact |
| `data/processed/` | Reserved for derived products; currently minimal |
| `archive/historical_raw/` | Preserved historical project inputs |
| `science/utils/` | FITS inspection and reading utilities |
| `science/validation/` | Standalone audit and external-query scripts |
| `backend/`, `frontend/` | Application structure is not yet implemented |
| `docs/` | Scientific context, audit records, requirements, inventory, vision, and roadmap |

## Development status

The workspace has a Python 3.12 virtual environment at `.venv312`, but required scientific and web dependencies are not all installed there. A pure-Python FITS header reader has been exercised on a local observation; this does not mean the full pipeline or application works. The `tests/` directory currently has no substantive automated tests. See [docs/PROJECT_VISION.md](docs/PROJECT_VISION.md) for the phased roadmap and [docs/EXTERNAL_DATA_VALIDATION_REPORT.md](docs/EXTERNAL_DATA_VALIDATION_REPORT.md) alongside the saved response artifacts for external query status.
