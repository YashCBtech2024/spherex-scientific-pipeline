#!/usr/bin/env python3
"""Fetch a JPL Horizons observer ephemeris and preserve raw response.

Install: pip install requests pandas
Example:
python fetch_horizons_ephemeris.py --target 433 --start 2026-10-01 --stop 2026-10-05 --step "1 d"
"""
import argparse, re
from pathlib import Path
from io import StringIO
import requests
import pandas as pd

URL = "https://ssd.jpl.nasa.gov/api/horizons.api"

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--target", default="433", help="Horizons target; 433 is asteroid 433 Eros")
    p.add_argument("--start", required=True, help="Start date YYYY-MM-DD")
    p.add_argument("--stop", required=True, help="Stop date YYYY-MM-DD")
    p.add_argument("--step", default="1 d", help='Step, e.g. "1 d" or "1 h"')
    p.add_argument("--center", default="500@399", help="Observer centre; 500@399 is geocentric")
    p.add_argument("--outdir", default="raw/horizons")
    a = p.parse_args()
    out = Path(a.outdir); out.mkdir(parents=True, exist_ok=True)
    params = {
        "format": "json", "COMMAND": f"'{a.target}'", "OBJ_DATA": "'YES'",
        "MAKE_EPHEM": "'YES'", "EPHEM_TYPE": "'OBSERVER'",
        "CENTER": f"'{a.center}'", "START_TIME": f"'{a.start}'",
        "STOP_TIME": f"'{a.stop}'", "STEP_SIZE": f"'{a.step}'",
        "QUANTITIES": "'1,9,20,23,24'"
    }
    response = requests.get(URL, params=params, timeout=120)
    response.raise_for_status()
    payload = response.json()
    (out/"horizons_raw_response.json").write_text(response.text)
    result = payload.get("result", "")
    if payload.get("error"):
        raise RuntimeError(payload["error"])
    match = re.search(r"\$\$SOE(.*?)\$\$EOE", result, flags=re.S)
    if not match:
        raise RuntimeError("Could not locate Horizons ephemeris table. Inspect raw response.")
    block = match.group(1).strip()
    # Horizons CSV rows are comma-separated when CSV_FORMAT=YES is requested.
    # Re-query in CSV mode for easier parsing.
    params["CSV_FORMAT"] = "YES"
    response2 = requests.get(URL, params=params, timeout=120)
    response2.raise_for_status()
    payload2 = response2.json()
    result2 = payload2.get("result", "")
    (out/"horizons_csv_response.json").write_text(response2.text)
    match2 = re.search(r"\$\$SOE(.*?)\$\$EOE", result2, flags=re.S)
    if not match2:
        raise RuntimeError("Could not parse CSV-format ephemeris table.")
    lines = [x.strip() for x in match2.group(1).splitlines() if x.strip()]
    # Save the untouched ephemeris table; column interpretation is version/quantity dependent.
    raw_csv = out/"horizons_ephemeris_table.csv"
    raw_csv.write_text("\n".join(lines) + "\n")
    print("Saved raw Horizons responses and ephemeris table to", out)
    print("Review the table header/column labels before mapping to jpl_ephemeris_template.csv.")

if __name__ == "__main__":
    main()
