#!/usr/bin/env bash
set -euo pipefail
# Requires Kaggle CLI installed and ~/.kaggle/kaggle.json configured.
mkdir -p raw/kaggle/asteroid raw/kaggle/hipparcos

kaggle datasets download -d sakhawat18/asteroid-dataset \
  -p raw/kaggle/asteroid --unzip

kaggle datasets download -d konivat/hipparcos-star-catalog \
  -p raw/kaggle/hipparcos --unzip

echo "Downloads complete. Inspect actual filenames, columns, units and licences before use."
