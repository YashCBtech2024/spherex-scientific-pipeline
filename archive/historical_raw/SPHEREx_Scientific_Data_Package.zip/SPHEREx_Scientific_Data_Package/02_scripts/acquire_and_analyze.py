#!/usr/bin/env python3
"""
SPHEREx / reference-data acquisition starter.
Requires: pip install requests pandas astropy

This script:
1) queries IRSA SIA2 for SPHEREx images covering a user-supplied sky position;
2) saves the returned metadata table;
3) optionally downloads a limited number of FITS files;
4) includes coordinate-aware separation and simple uncertainty calculations.

It does NOT extract source positions from FITS images. Source extraction/photometry
must be performed with the IRSA Source Discovery Tool, a documented photometry
pipeline, or an agreed source-detection method.
"""
import argparse
from pathlib import Path
import math
import requests
import pandas as pd

SIA_URL = "https://irsa.ipac.caltech.edu/SIA"

def query_spherex(ra, dec, radius_deg, collection, outdir, max_downloads=0):
    params = {
        "COLLECTION": collection,
        "POS": f"circle {ra} {dec} {radius_deg}",
        "RESPONSEFORMAT": "csv"
    }
    r = requests.get(SIA_URL, params=params, timeout=120)
    r.raise_for_status()
    outdir.mkdir(parents=True, exist_ok=True)
    csv_path = outdir / "spherex_sia_results.csv"
    csv_path.write_bytes(r.content)
    try:
        table = pd.read_csv(csv_path)
    except Exception:
        print("IRSA response saved, but was not parsed as CSV. Inspect:", csv_path)
        return
    print(f"Found {len(table)} archive rows. Saved {csv_path}")
    print("Columns:", list(table.columns))
    # SIA2 typically returns access_url; keep original archive table untouched.
    url_col = next((c for c in table.columns if c.lower() == "access_url"), None)
    if max_downloads and url_col:
        fits_dir = outdir / "fits"
        fits_dir.mkdir(exist_ok=True)
        urls = table[url_col].dropna().astype(str).head(max_downloads)
        for i, url in enumerate(urls, 1):
            resp = requests.get(url, timeout=300)
            resp.raise_for_status()
            path = fits_dir / f"spherex_{i:03d}.fits"
            path.write_bytes(resp.content)
            print("Downloaded", path)

def angular_separation_arcsec(ra1_deg, dec1_deg, ra2_deg, dec2_deg):
    """Great-circle separation using the haversine form; returns arcseconds."""
    ra1, dec1, ra2, dec2 = map(math.radians, [ra1_deg, dec1_deg, ra2_deg, dec2_deg])
    dra = ra2 - ra1
    ddec = dec2 - dec1
    a = math.sin(ddec/2)**2 + math.cos(dec1)*math.cos(dec2)*math.sin(dra/2)**2
    a = min(1.0, max(0.0, a))
    return math.degrees(2*math.asin(math.sqrt(a))) * 3600.0

def motion_summary(ra1, dec1, t1_days, ra2, dec2, t2_days,
                   sigma1_arcsec=None, sigma2_arcsec=None):
    sep = angular_separation_arcsec(ra1, dec1, ra2, dec2)
    dt = t2_days - t1_days
    if dt <= 0:
        raise ValueError("Second observation time must be later than first.")
    result = {"angular_displacement_arcsec": sep,
              "elapsed_days": dt,
              "mean_motion_arcsec_day": sep/dt}
    if sigma1_arcsec is not None and sigma2_arcsec is not None:
        sig = math.hypot(sigma1_arcsec, sigma2_arcsec)
        result["combined_position_error_arcsec"] = sig
        result["significance_sigma"] = sep/sig if sig > 0 else None
    return result

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--ra", type=float, required=True, help="Search centre RA in degrees")
    p.add_argument("--dec", type=float, required=True, help="Search centre Dec in degrees")
    p.add_argument("--radius-deg", type=float, default=0.0138889)
    p.add_argument("--collection", choices=["spherex_qr3","spherex_qr3_deep",
                                            "spherex_qr2","spherex_qr2_deep"],
                   default="spherex_qr3")
    p.add_argument("--outdir", default="raw/spherex")
    p.add_argument("--download", type=int, default=0,
                   help="Download at most this many returned FITS files")
    args = p.parse_args()
    query_spherex(args.ra, args.dec, args.radius_deg, args.collection,
                  Path(args.outdir), args.download)

if __name__ == "__main__":
    main()
