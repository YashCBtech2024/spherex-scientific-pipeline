# SPHEREx Scientific Data Package (starter handover)

## What is included
- Header-only CSV templates for SPHEREx observations/source positions, asteroid catalogue,
  Hipparcos stars, JPL ephemerides, candidate analysis and validation cases.
- A dataset dictionary workbook.
- A Python acquisition/analysis starter script.
- Source links, provenance notes and important scientific cautions.

## IMPORTANT: data status
This package is a **starter handover kit**, not a populated scientific catalogue.
No astronomical measurements have been invented. CSV files contain headers only;
the JSON file is a schema/example with null values. The live SPHEREx archive and
Kaggle downloads have not been bundled because they are large and/or require
query parameters or Kaggle account/API access.

## Recommended source roles
1. SPHEREx IRSA QR3/QR2: primary observed mission data (FITS spectral images).
2. JPL Horizons: predicted positions of known Solar System bodies for validation.
3. Kaggle asteroid dataset: orbital/object properties, not an observed RA/Dec time series.
4. Kaggle Hipparcos catalogue: stellar astrometry/proper motions; epoch and units must be
   handled before comparison with SPHEREx observations.

## SPHEREx archive access
IRSA SIA2 endpoint: https://irsa.ipac.caltech.edu/SIA
Collections:
- spherex_qr3 (wide survey)
- spherex_qr3_deep
- spherex_qr2 (wide survey)
- spherex_qr2_deep

The acquisition script accepts a sky position and search radius, queries SIA2,
saves the returned observation table and optionally downloads a small number of FITS
products. `download_kaggle_datasets.sh` retrieves the two Kaggle datasets after Kaggle
CLI authentication. `fetch_horizons_ephemeris.py` retrieves and preserves a Horizons
ephemeris response for a selected target and date interval. Select a field/target and dates with your team before bulk retrieval.

## Kaggle downloads
Install Kaggle CLI and configure your Kaggle API token first:
  pip install kaggle
  kaggle datasets download -d sakhawat18/asteroid-dataset -p raw/kaggle --unzip
  kaggle datasets download -d konivat/hipparcos-star-catalog -p raw/kaggle --unzip

Check each dataset's current version, data card, licence, field names, units and provenance.
Do not assume the Kaggle file schema is identical to the normalized templates.

## Install script dependencies
  pip install -r 03_documentation/requirements.txt\n# Also install Kaggle CLI separately if downloading Kaggle datasets: pip install kaggle

## Run
  python 02_scripts/acquire_and_analyze.py --ra 150.7817877 --dec 3.3502204 --radius-deg 0.0138889 --collection spherex_qr3 --download 2\npython 02_scripts/fetch_horizons_ephemeris.py --target 433 --start 2026-10-01 --stop 2026-10-05\nbash 02_scripts/download_kaggle_datasets.sh

This is an example sky position used in an IRSA tutorial (COSMOS field), not a
team-approved science target. The dates are query parameters; change them to the
project's selected observation interval.

## Scientific cautions
- Do not equate a SPHEREx image product with a source catalogue. Source positions
  must be measured/extracted using a documented method or obtained from a supported
  source-discovery product.
- Match sources across epochs with a spherical-coordinate method and uncertainty-aware
  association; do not match by row order or pixel position alone.
- RA differences must be treated with spherical geometry. For small separations,
  the tangent-plane approximation uses delta_RA*cos(dec).
- Hipparcos proper motion and epoch must be propagated consistently; pmRA in the
  Hipparcos convention includes cos(dec).
- Horizons ephemerides are predictions, not SPHEREx detections.
- SPHEREx spectral channels/wavelengths should be compared consistently; the broad
  wavelength groups in the team's meeting notes are not the 102 individual bands.
- Preserve raw files and metadata. Record query parameters, retrieval date, collection,
  product IDs, software versions and licence/DOI.

## Sources
- SPHEREx IRSA mission/archive: https://irsa.ipac.caltech.edu/Missions/spherex.html
- SPHEREx QR overview: https://irsa.ipac.caltech.edu/data/SPHEREx/docs/overview_qr.html
- SPHEREx archive data products: https://caltech-ipac.github.io/spherex-archive-documentation/spherex-data-products/
- SPHEREx archive access/SIA2: https://caltech-ipac.github.io/spherex-archive-documentation/spherex-data-access/
- IRSA Source Discovery Tool tutorial: https://caltech-ipac.github.io/irsa-tutorials/spherex-source-discovery-tool-demo/
- Kaggle asteroid dataset: https://www.kaggle.com/datasets/sakhawat18/asteroid-dataset
- Kaggle Hipparcos catalogue: https://www.kaggle.com/datasets/konivat/hipparcos-star-catalog
- JPL Horizons API: https://ssd-api.jpl.nasa.gov/doc/horizons.html

## QR release citation
For QR3 data, cite DOI: 10.26131/IRSA662. For QR2, cite DOI: 10.26131/IRSA652.
Include the SPHEREx acknowledgement specified in the IRSA QR overview.
